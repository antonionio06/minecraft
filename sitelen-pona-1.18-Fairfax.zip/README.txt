This resource pack replaces all the minecraft toki pona translations with sitelen pona using a python script (located at assets/minecraft/lang).
It's quite buggy, so feel free to modify it.
To display the translation select toki pona in languages (it'll be written in sitelen pona)
Font used - Fairfax.
Also, I don't know, why does this resourcepack require optifine, maybe it has something to do witth the fact, that Fairfax is 15 times larger than linja sike or something.
-jan Ate