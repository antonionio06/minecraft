This resource pack replaces all the minecraft toki pona translations with sitelen pona using a python script (located at assets/minecraft/lang).
It's quite buggy, so feel free to modify it.
To display the translation select toki pona in languages (it'll be written in sitelen pona)
Font used - Fairfax.
Known issues:
-For some reason it requires optifine, even though, usually resourcepacks changing fonts don't.
-The glyph COMBINING CARTOUCHE EXTENSION is for some reason shifted by one character to the left, making cartouches render incorrectly.

-jan Ate